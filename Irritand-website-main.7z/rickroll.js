let peop = document.querySelector("#poep");

peop.addEventListener('click', pop);

function pop() {
    window.open('https://www.youtube.com/watch?v=dQw4w9WgXcQ');
}