let butto = document.querySelector("#button");

butto.addEventListener('click', function(){
    window.open('https://irriweb.basbrouwer.site/website.html', '_self');
})
